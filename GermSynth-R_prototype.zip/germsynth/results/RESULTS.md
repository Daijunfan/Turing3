# GermSynth-R exact experiment results

**Overall status:** `PASS`

The complete command `./reproduce.sh` finished with:

```text
11 passed
CXX_INDEPENDENT_VERIFICATION=PASS
CXX_POOL_INDEPENDENT_VERIFICATION=PASS
FULL_REPRODUCTION=PASS
```

## Discovered germs

| Problem | Automatically discovered rank | Exact base cases | Recursive exponent |
|---|---:|---:|---:|
| Degree-1 polynomial multiplication | 3 | 625 | 1.584962500721 |
| 2x2 matrix multiplication | 7 | 6561 | 2.807354922058 |

The matrix search ran 20 deterministic seeds, found a rank-7 support and an exact integer lift in every run, and produced 16 distinct coefficient phenotypes. The selected primary support was reached from the schoolbook rank-8 decomposition after 171 exact local flips.

## Largest recursive checks

| Algorithm family | Largest size | Exact scalar multiplications | Schoolbook count | Equality |
|---|---:|---:|---:|---|
| Matrix multiplication | 128 x 128 | 823543 = 7^7 | 2097152 | PASS |
| Polynomial multiplication | 1024 coefficients | 59049 = 3^10 | 1048576 | PASS |

A 64x64 matrix product using a different exact phenotype at arbitrary recursive nodes passed with exactly 117649 scalar multiplications.

## Regenerative cover

| Pool | Single failures | Double failures | Triple failures |
|---|---:|---:|---:|
| One fixed phenotype | 23/44 | 253/946 | 1771/13244 |
| Full 16-phenotype pool | 44/44 | 871/946 | 9695/13244 |
| Exact minimum 3-phenotype single-fault cover | 44/44 | 622/946 | 4874/13244 |

The independent verifiers exhaustively rejected every one- and two-phenotype subset as a full single-fault cover. A strict 32x32 run sampled one unavailable resource independently at every recursive node, allowed no fallback, and passed with exactly 16807 = 7^5 scalar multiplications.

## Verification boundary

The local identities use exact integer arithmetic. Universal power-of-two correctness follows by structural induction on block substitution. Random large-size checks validate the implementation/proof correspondence; they are not the logical basis of the universal theorem.

Not claimed:

- a new matrix multiplication exponent;
- physical fault tolerance outside the declared abstract resource model;
- numerical stability for floating-point implementations;
- certainty of receiving a Turing Award.
